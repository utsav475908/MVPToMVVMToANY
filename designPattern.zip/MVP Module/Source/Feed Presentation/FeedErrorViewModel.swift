//
//  Copyright © Essential Developer. All rights reserved.
//

struct FeedErrorViewModel {
	let message: String?
}

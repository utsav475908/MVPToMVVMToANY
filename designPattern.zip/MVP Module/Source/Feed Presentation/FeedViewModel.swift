//
//  Copyright © Essential Developer. All rights reserved.
//

import FeedFeature

struct FeedViewModel {
	let feed: [FeedImage]
}

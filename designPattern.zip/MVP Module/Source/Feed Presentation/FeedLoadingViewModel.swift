//
//  Copyright © Essential Developer. All rights reserved.
//

struct FeedLoadingViewModel {
	let isLoading: Bool
}

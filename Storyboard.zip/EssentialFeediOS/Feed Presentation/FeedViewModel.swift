//
//  Copyright © 2019 Essential Developer. All rights reserved.
//

import EssentialFeed

struct FeedViewModel {
	let feed: [FeedImage]
}
